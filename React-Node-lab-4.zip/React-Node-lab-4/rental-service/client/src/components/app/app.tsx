import {MainPage} from "../../pages/main-page/main-page";

function App() {
    return (
      <MainPage/>
    );
}

export { App };